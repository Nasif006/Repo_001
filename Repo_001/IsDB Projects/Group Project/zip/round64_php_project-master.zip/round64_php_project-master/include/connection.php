<?php
include 'class/crud.php';
$mysqli=new crud();
